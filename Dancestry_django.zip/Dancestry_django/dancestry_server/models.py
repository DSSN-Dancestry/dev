# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = True` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

class ArtistProfile(models.Model):
    artist_profile_id = models.AutoField(primary_key=True)
    is_user_artist = models.CharField(max_length=10)
    profile_name = models.CharField(max_length=50)
    past_profile_name = models.CharField(max_length=50, blank=True, null=True)
    artist_first_name = models.CharField(max_length=50)
    artist_last_name = models.CharField(max_length=100)
    artist_email_address = models.CharField(max_length=100)
    artist_living_status = models.CharField(max_length=10,blank=True)
    artist_dob = models.DateField(blank=True,null=True)
    artist_dod = models.DateField(default=None,blank=True,null=True)
    artist_genre = models.CharField(max_length=150,blank=True)
    artist_ethnicity = models.CharField(max_length=50,blank=True)
    artist_gender = models.CharField(max_length=50,blank=True,null=True)
    gender_other = models.CharField(max_length=100,blank=True)
    genre_other = models.CharField(max_length=100,blank=True)
    ethnicity_other = models.CharField(max_length=100,blank=True)
    artist_residence_city = models.CharField(max_length=100,blank=True)
    artist_residence_state = models.CharField(max_length=100,blank=True)
    artist_residence_province = models.CharField(max_length=100,blank=True)
    artist_residence_country = models.CharField(max_length=100,blank=True)
    artist_birth_country = models.CharField(max_length=100,blank=True)
    artist_biography = models.CharField(max_length=500,blank=True)
    artist_biography_text = models.CharField(max_length=4000,blank=True)
    artist_photo_path = models.CharField(max_length=500,blank=True,null=True)
    artist_website = models.CharField(max_length=100, blank=True, null=True)
    status = models.IntegerField(db_column='STATUS')  # Field name made lowercase.
    genre = models.CharField(max_length=3000, blank=True, null=True)
    user_genres = models.CharField(max_length=1000, blank=True, null=True)
    last_update_date = models.DateTimeField(blank=True, null=True)
    completed_date = models.DateTimeField(blank=True, null=True)
    reference_details = models.CharField(max_length=4000, blank=True, null=True)
    artist_birth_year = models.CharField(max_length=4000, blank=True, null=True)
    artist_phone = models.CharField(max_length=4000, blank=True, null=True)
    facebook_handle = models.CharField(max_length=4000, blank=True, null=True)
    instagram_handle = models.CharField(max_length=4000, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'artist_profile'
        unique_together = (('artist_first_name', 'artist_last_name', 'artist_email_address'),)

class ArtistBackup(models.Model):
    artist_profile_id = models.IntegerField()
    is_user_artist = models.CharField(max_length=10)
    profile_name = models.CharField(max_length=50)
    past_profile_name = models.CharField(max_length=50, blank=True, null=True)
    artist_first_name = models.CharField(max_length=50)
    artist_last_name = models.CharField(max_length=100)
    artist_email_address = models.CharField(max_length=50)
    artist_living_status = models.CharField(max_length=10)
    artist_dob = models.DateField()
    artist_dod = models.DateField()
    artist_genre = models.CharField(max_length=150)
    artist_ethnicity = models.CharField(max_length=50)
    artist_gender = models.CharField(max_length=50)
    gender_other = models.CharField(max_length=100)
    genre_other = models.CharField(max_length=100)
    ethnicity_other = models.CharField(max_length=100)
    artist_residence_city = models.CharField(max_length=100)
    artist_residence_state = models.CharField(max_length=100)
    artist_residence_province = models.CharField(max_length=100)
    artist_residence_country = models.CharField(max_length=100)
    artist_birth_country = models.CharField(max_length=100)
    artist_biography = models.CharField(max_length=500)
    artist_biography_text = models.CharField(max_length=1000)
    artist_photo_path = models.CharField(max_length=500)
    artist_website = models.CharField(max_length=100, blank=True, null=True)
    status = models.IntegerField(db_column='STATUS')  # Field name made lowercase.
    genre = models.CharField(max_length=3000, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'artist_backup'


class ArtistEducation(models.Model):
    artist_email_id = models.CharField(max_length=100)
    artist_profile_id = models.IntegerField()
    education_type = models.CharField(max_length=200)
    institution_name = models.CharField(max_length=200)
    major = models.CharField(max_length=200)
    degree = models.CharField(max_length=200)

    class Meta:
        managed = True
        db_table = 'artist_education'


class ArtistGenres(models.Model):
    artist_genre_id = models.AutoField(primary_key=True)
    artist_profile_id = models.IntegerField(blank=True, null=True)
    genre_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'artist_genres'



class ArtistRelation(models.Model):
    relation_id = models.AutoField(primary_key=True)
    artist_profile_id_1 = models.IntegerField()
    artist_profile_id_2 = models.IntegerField()
    artist_name_1 = models.CharField(max_length=255)
    artist_email_id_1 = models.CharField(max_length=100)
    artist_name_2 = models.CharField(max_length=255)
    artist_email_id_2 = models.CharField(max_length=100)
    artist_website_2 = models.CharField(max_length=200,blank=True,null=True)
    artist_relation = models.CharField(max_length=100)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    duration_years = models.IntegerField(blank=True, null=True)
    duration_months = models.IntegerField(blank=True, null=True)
    relation_identifier = models.CharField(max_length=250,blank=True, null=True)
    works = models.CharField(max_length=1000, blank=True, null=True)
    relation_genres = models.CharField(max_length=1000, blank=True, null=True)
    relation_user_genres = models.CharField(max_length=1000, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'artist_relation'
        unique_together = (('artist_profile_id_1', 'artist_profile_id_2', 'artist_relation'),)


class ArtistRelationBackup(models.Model):
    relation_id = models.IntegerField()
    artist_profile_id_1 = models.IntegerField()
    artist_profile_id_2 = models.IntegerField()
    artist_name_1 = models.CharField(max_length=255)
    artist_email_id_1 = models.CharField(max_length=100)
    artist_name_2 = models.CharField(max_length=255)
    artist_email_id_2 = models.CharField(max_length=100)
    artist_website_2 = models.CharField(max_length=200)
    artist_relation = models.CharField(max_length=100)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField()
    duration_years = models.IntegerField()
    duration_months = models.IntegerField()
    relation_identifier = models.CharField(max_length=250)
    works = models.CharField(max_length=1000, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'artist_relation_backup'


class ArtistWorks(models.Model):
    artist_works_id = models.AutoField(primary_key=True)
    artist_profile_id = models.IntegerField(blank=True, null=True)
    work_id = models.IntegerField(blank=True, null=True)
    involvement = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'artist_works'


class BugComments(models.Model):
    id = models.IntegerField(blank=True,primary_key=True)
    comment = models.CharField(max_length=255, db_collation='utf8_unicode_ci')
    uploaded_on = models.DateTimeField()

    class Meta:
        managed = True
        db_table = 'bug_comments'


class Bugs(models.Model):
    file_name = models.CharField(max_length=255)
    uploaded_on = models.DateTimeField()
    status = models.CharField(max_length=1)
    user_email_id = models.CharField(max_length=100, blank=True, null=True)
    user_name = models.CharField(max_length=50, blank=True, null=True)
    user_comment = models.CharField(max_length=4000, blank=True, null=True)
    issue_title = models.CharField(max_length=150, blank=True, null=True)
    category = models.CharField(max_length=15, blank=True, null=True)
    severity = models.CharField(max_length=15, blank=True, null=True)
    assigned_to = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'bugs'


class EventPlanner(models.Model):
    event_id = models.AutoField(primary_key=True)
    user_email_id = models.CharField(max_length=100)
    event_name = models.CharField(max_length=100)
    event_location = models.CharField(max_length=100)
    event_description = models.CharField(max_length=255, blank=True, null=True)
    event_startdate = models.DateField()
    event_time = models.TimeField(blank=True, null=True)
    last_notified = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'event_planner'


class Genres(models.Model):
    genre_id = models.AutoField(primary_key=True)
    category = models.CharField(max_length=100, blank=True, null=True)
    genre_name = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'genres'


class NetworkCache(models.Model):
    pid = models.IntegerField(db_column='PID', primary_key=True)  # Field name made lowercase.
    x = models.IntegerField()
    y = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'network_cache'


class PhoneAppointments(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    contact = models.CharField(max_length=20)
    note = models.CharField(max_length=300)
    status = models.CharField(max_length=20)
    submitted_date = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'phone_appointments'


class UserProfBack(models.Model):
    user_id = models.IntegerField()
    user_first_name = models.CharField(max_length=100)
    user_last_name = models.CharField(max_length=100)
    user_email_address = models.CharField(max_length=255)
    user_password = models.CharField(max_length=255)
    user_one_time_password = models.IntegerField()
    user_type = models.CharField(max_length=20)

    class Meta:
        managed = True
        db_table = 'user_prof_back'


class UserProfile(models.Model):
    user_id = models.AutoField(primary_key=True)
    user_first_name = models.CharField(max_length=100)
    user_last_name = models.CharField(max_length=100)
    user_email_address = models.CharField(unique=True, max_length=255)
    user_password = models.CharField(max_length=255)
    user_one_time_password = models.IntegerField()
    user_type = models.CharField(max_length=20)
    user_security_question = models.CharField(max_length=400,default="Who's your favourite childhood teacher?")
    user_security_question_answer = models.CharField(max_length=100,default="Mom")

    class Meta:
        managed = True
        db_table = 'user_profile'

class Works(models.Model):
    work_id = models.AutoField(primary_key=True)
    type = models.CharField(max_length=100, blank=True, null=True)
    genre = models.CharField(max_length=100, blank=True, null=True)
    name = models.CharField(max_length=300, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'works'