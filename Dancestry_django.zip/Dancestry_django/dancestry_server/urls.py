from django.urls import path
from . import views

urlpatterns = [
    path('about',views.about),
    path('artist_profiles',views.artist_profile_view,name="artist_details"),
    path('artist_relation',views.artist_relation_view,name="artist_relation"),
    path('user_profiles',views.user_profile_view,name='user_profiles'),
    path('user_login',views.user_login,name='user_login'),
    path('save_user_profile',views.save_user_profile,name="save_user_profile"),
    path('save_artist_profile',views.save_artist_profile,name="save_artist_profile"),
    path('get_artist_profile',views.get_artist_profile,name="get_artist_profile"),
    path('forgot_user_profile_password',views.forgot_user_profile_password,name="forgot_user_profile_password"),
    path('get_artist_relation',views.get_artist_relation,name="get_artist_relation"),
    path('add_new_artist_relation',views.add_new_artist_relation,name="add_new_artist_relation"),
    path('add_existing_artist_relation',views.add_existing_artist_relation,name="add_existing_artist_relation"),
    path('home',views.home_view,name="home_path"),
    path('is_existing_artist',views.is_existing_artist,name="is_existing_artist"),
    path('get_user_security_question',views.get_user_security_question,name="get_user_security_question"),
    path('forgot_user_profile_password',views.forgot_user_profile_password,name="forgot_user_profile_password"),
    path('get_artist_profile_by_lastname',views.get_artist_profile_by_lastname,name="get_artist_profile_by_lastname"),
    path('get_full_network',views.get_full_network,name="get_full_network"),
    path('get_artist_relation_by_Name',views.get_artist_relation_by_Name,name="get_artist_relation_by_Name"),
    path('get_artist_profile_relations',views.get_artist_profile_relations,name="get_artist_profile_relations"),
    path('get_artist_profile_relation_by_Id',views.get_artist_profile_relation_by_Id,name="get_artist_profile_relation_by_Id")
]