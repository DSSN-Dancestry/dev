from pickle import NONE
from django.db.models import fields
from rest_framework import routers, serializers, viewsets
from .models import *

class GenresModelSerializer(serializers.ModelSerializer):

    class Meta:
        model = Genres
        fields = '__all__'

class ArtistEducationSerializer(serializers.ModelSerializer):

    class Meta:
        model =  ArtistEducation
        fields = '__all__'

class ArtistGenresSerializer(serializers.ModelSerializer):

    class Meta:
        model = ArtistGenres
        fields = '__all__'

class ArtistProfileSrializer(serializers.ModelSerializer):

    class Meta:
        model = ArtistProfile
        fields = '__all__'

    def create(self,validated_data):
        print("Printing artist profile")
        print(validated_data)
        print("printing the birth year")
        print(validated_data.get('artist_birth_year'))
        artist_profile = ArtistProfile.objects.create(
            is_user_artist = "artist",
            profile_name = validated_data.get('artist_email_address'),
            artist_first_name = validated_data.get('artist_first_name'),
            artist_last_name = validated_data.get('artist_last_name'),
            artist_email_address = validated_data.get('artist_email_address'),
            artist_living_status = " ",
            artist_dob = validated_data.get('artist_dob'),
            artist_dod = None,
            artist_genre = " ",
            artist_ethnicity = " ",
            artist_gender = None,
            gender_other = " ",
            genre_other = " ",
            ethnicity_other = " ",
            artist_residence_city = " ",
            artist_residence_state = " ",
            artist_residence_province = " ",
            artist_residence_country = " ",
            artist_birth_country = " ",
            artist_biography = " ",
            artist_biography_text = " ",
            artist_photo_path = validated_data.get('artist_photo_path'),
            artist_website = " ",
            status = 100,
            genre = " ",
            user_genres = " ",
            last_update_date = None,
            completed_date =None,
            reference_details = None,
            artist_birth_year = validated_data.get('artist_birth_year'),
            artist_phone = validated_data.get('artist_phone'),
            facebook_handle = validated_data.get('facebook_handle'),
            instagram_handle = validated_data.get('instagram_handle')


        )
        artist_profile.save()
        print(artist_profile)
        return artist_profile

    def update(self,validated_data):
        print("printing the validated data")
        print(validated_data)
        artist_profile = ArtistProfile.objects.filter(artist_first_name=validated_data.get('artist_first_name'),
                     artist_last_name=validated_data.get('artist_last_name'),artist_email_address=validated_data.get('artist_email_address')).first()
        print("printing the birth year")
        print(validated_data.get('artist_birth_year'))
        print(artist_profile)
        if((artist_profile)):
            print("Preparing data to save")
            artist_profile.profile_name = validated_data.get('artist_email_address')
            artist_profile.artist_first_name = validated_data.get('artist_first_name')
            artist_profile.artist_last_name = validated_data.get('artist_last_name')
            artist_profile.artist_email_address = validated_data.get('artist_email_address')
            artist_profile.artist_dob = validated_data.get('artist_dob')
            artist_profile.artist_gender = validated_data.get('artist_gender')
            artist_profile.artist_photo_path = validated_data.get('artist_photo_path')
            artist_profile.artist_birth_year = validated_data.get('artist_birth_year')
            artist_profile.artist_phone = validated_data.get('artist_phone')
            artist_profile.facebook_handle = validated_data.get('facebook_handle')
            artist_profile.instagram_handle = validated_data.get('instagram_handle')
            artist_profile.save()
            return artist_profile
        return None

class ArtistRelationSerializer(serializers.ModelSerializer):

    class Meta:
        model = ArtistRelation
        fields = '__all__'

        # def create(self,validated_data):
        #     validated_data.save()

        def create(self,validated_data):
            artist_relation = ArtistRelation.objects.create(
                artist_profile_id_1 = validated_data.get('artist_profile_id_1'),
                artist_profile_id_2 = validated_data.get('artist_profile_id_2'),
                artist_name_1 = validated_data.get('artist_name_1'),
                artist_email_id_1 = validated_data.get('artist_email_id_1'),
                artist_name_2 = validated_data.get('artist_name_2'),
                artist_email_id_2 = validated_data.get('artist_email_id_2'),
                artist_website_2 = "",
                artist_relation = validated_data.get('artist_relation'),
                start_date = None,
                end_date = None,
                duration_years = None,
                duration_months = None,
                relation_identifier = None,
                works = None,
                relation_genres = None,
                relation_user_genres = None
            )
            print("Trying to save artist relation")
            artist_relation.save()
            return artist_relation

        def update(self,validated_data):
            artist_relation = ArtistRelation.objects.filter(relation_id = validated_data.get('relation_id')).first()
            if(artist_relation is not None):
                artist_relation.artist_profile_id_1 = validated_data.get('artist_profile_id_1')
                artist_relation.artist_profile_id_2 = validated_data.get('artist_profile_id_2')
                artist_relation.artist_name_1 = validated_data.get('artist_name_1')
                artist_relation.artist_email_id_1 = validated_data.get('artist_email_id_1')
                artist_relation.artist_name_2 = validated_data.get('artist_name_2')
                artist_relation.artist_email_id_2 = validated_data.get('artist_email_id_2')
                artist_relation.artist_relation = validated_data.get('artist_relation')
                artist_relation.save()
                return artist_relation
            else:
                return None

class ArtistWorksSerializer(serializers.ModelSerializer):

    class Meta:
        model = ArtistWorks
        fields = '__all__'

class PhoneAppointmentsSerializer(serializers.ModelSerializer):

    class Meta:
        model  = PhoneAppointments
        fields = '__all__'

class UserProfileSerializer(serializers.Serializer):
    user_first_name = serializers.CharField(max_length=100)
    user_last_name = serializers.CharField(max_length=100)
    user_email_address = serializers.CharField(max_length=255)
    user_password = serializers.CharField(max_length=255)
    user_one_time_password = 0
    user_type = "artist"
    user_security_question = serializers.CharField(max_length=400)
    user_security_question_answer = serializers.CharField(max_length=100)



    class Meta:
        model = UserProfile

    def update(self,validated_data):
        user_email = validated_data.get('user_email_address')
        if (user_email):
            user_profile = UserProfile.objects.filter(user_email_address = user_email).first()
            if(user_profile):
                print("hi")
                print(validated_data)
                user_profile.user_first_name = validated_data.get('user_first_name')
                user_profile.user_last_name = validated_data.get('user_last_name')
                user_profile.user_one_time_password = 0
                user_profile.user_type = "artist"
                user_profile.user_password = validated_data.get('user_password')
                user_profile.save()
                print(user_profile)
                return user_profile
        else:
            return None

    def create(self,validated_data):
        print(validated_data)
        user_profile = UserProfile.objects.create(
            user_first_name = validated_data.get('user_first_name'),
            user_last_name = validated_data.get('user_last_name'),
            user_email_address = validated_data.get('user_email_address'),
            user_password = validated_data.get('user_password'),
            user_one_time_password = 0,
            user_type = "artist",
            user_security_question = validated_data.get('user_security_question'),
            user_security_question_answer = validated_data.get('user_security_question_answer')

        )
        print("Saving")
        print(user_profile)
        user_profile.save()
        return user_profile

class WorksSerializer(serializers.ModelSerializer):

    class Meta:
        model = Works
        fields = '__all__'