from email import message
from urllib import response
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from .models import *
from .serializer import *
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from rest_framework.decorators import authentication_classes, permission_classes, api_view
from rest_framework.parsers import JSONParser
import json
import string
import random
import hashlib

# Create your views here.

def about(request):
    # profiles = ArtistProfile.objects.all()
    # profiles_serializer = ArtistProfileModelSerializer(profiles)
    gerners = Genres.objects.all()
    genere_serializer  = GenresModelSerializer(gerners,many=True)
    # for d in gerners:
    #     print(d.genre_name)
    print(genere_serializer)
    return Response(genere_serializer.data)

@permission_classes([])
class GenresAPIView(APIView):

    def get(self,request,format=None):
        gerners = Genres.objects.all()
        genres_serializer = GenresModelSerializer(gerners,many=True)
        print(genres_serializer.data)
        return Response(genres_serializer.data)


@api_view(['GET',])
@permission_classes([])
def artist_profile_view(request):
    artist_profile = ArtistProfile.objects.all()
    artist_serialized_data = ArtistProfileSrializer(artist_profile,many=True)
    return Response(artist_serialized_data.data)


@api_view(['GET',])
@permission_classes([])
def artist_relation_view(request):
    artist_relation = ArtistRelation.objects.all()
    artist_relation_data = ArtistRelationSerializer(artist_relation,many=True)
    return Response(artist_relation_data.data)

@api_view(['GET',])
@permission_classes([])
def user_profile_view(request):
    data = request.data
    user_profiles = UserProfile.objects.all()
    if(data):
        print(data.get('user_email_address'))
        user_profiles = UserProfile.objects.filter(user_email_address = data.get('user_email_address'))
    user_profiles_data = UserProfileSerializer(user_profiles,many=True)
    return Response(user_profiles_data.data)


@api_view(['POST',])
@permission_classes([])
def user_login(request):
    data = request.data
    response_msg = {}
    if(data):
        user_profiles = UserProfile.objects.filter(user_email_address = data.get('user_email_address'))
        if(user_profiles):
            user_profiles_data = UserProfileSerializer(user_profiles,many=True)
            user_profile_dict = json.loads(json.dumps(user_profiles_data.data))
            if(data.get('user_password') == user_profile_dict[0].get('user_password')):
                response_msg.update({"msg" : "Logged in Successfully"})
                response_msg.update({"user_first_name" : user_profile_dict[0].get('user_first_name')})
                response_msg.update({"user_last_name" : user_profile_dict[0].get('user_last_name')})
                response_msg.update({"user_email_address" : user_profile_dict[0].get('user_email_address')})
                return JsonResponse(response_msg,status=200)
            else:
                response_msg.update({"msg" : "Invalid Password"})
                return JsonResponse(response_msg,status=400)
        else:
            response_msg.update({"msg" : "Invalid Password"})
            return JsonResponse(response_msg,status=400)
    else:
        return JsonResponse("ERROR",status=400)


#if profile exists then update or else save
@api_view(['PUT'])
@permission_classes([])
def save_user_profile(request):
    data = JSONParser().parse(request)
    print("printing the request data!!!!")
    print(data)
    user_profiles = UserProfile.objects.filter(user_email_address = data.get('user_email_address'))
    print(len(user_profiles))
    save_user_profile_serializer = UserProfileSerializer(data=data)
    if(len(user_profiles) == 0):
        print("Creating new user")
        if(save_user_profile_serializer.is_valid()):
            save_user_profile_serializer.create(data)
            return JsonResponse(save_user_profile_serializer.data, status=200)
        return JsonResponse(save_user_profile_serializer.errors, status=400)
    else:
        if(save_user_profile_serializer.is_valid()):
            save_user_profile_serializer.update(data)
            return JsonResponse(save_user_profile_serializer.data, status=200)
        return JsonResponse(save_user_profile_serializer.errors, status=400)


@api_view(['PUT'])
@permission_classes([])
def save_artist_profile(request):
    data = JSONParser().parse(request)
    response_msg = {}
    artist_profile = ArtistProfile.objects.filter(artist_first_name=data.get('artist_first_name'),
                     artist_last_name=data.get('artist_last_name'),artist_email_address=data.get('artist_email_address'))
    print("Checking for existing Artists")
    print(artist_profile)
    save_artist_profile_serializer = ArtistProfileSrializer(data=data)
    if(len(artist_profile)==0):
        print('Creating new artist profiles')
        print("artist is serialized")
        save_artist_profile_serializer.create(data)
        response_msg.update({"msg" : "Artist Saved Succesfully"})
        return JsonResponse(response_msg,status=200)

    else:
        print("Updating the Data")
        save_artist_profile_serializer.update(data)
        response_msg.update({"msg" : "Artist Updated Succesfully"})
        return JsonResponse(response_msg,status=200)
    return JsonResponse(save_artist_profile_serializer.errors, status=400)

#retrive artist profiles based on the last name
@api_view(['PUT'])
@permission_classes([])
def get_artist_profile(request):
    data = request.data
    if(data):
        artist_profiles = ArtistProfile.objects.filter(artist_last_name = data.get('artist_last_name'),
                          artist_email_address = data.get('artist_email_address'),artist_first_name = data.get('artist_first_name'))
        if(artist_profiles):
            artist_profile_data = ArtistProfileSrializer(artist_profiles,many=True)
            artist_profile_dict = json.loads(json.dumps(artist_profile_data.data))
            return JsonResponse(artist_profile_dict[0],safe=False,status=200)
        else:
            return JsonResponse({"msg" : "New Artist"},safe=False,status=200)
    return Response("ERROR")


def add_artist_relation(artist_relation_serializer):
    if(artist_relation_serializer.is_valid()):
        artist_relation_serializer.save()
        return True
    else:
        return False

@api_view(['PUT'])
@permission_classes([])
def forgot_user_profile_password(request):
    data = JSONParser().parse(request)
    response_msg ={}
    user_profiles = UserProfile.objects.filter(user_email_address = data.get('user_email_address')).first()
    print("Checking for user")
    print(data.get('user_email_address'))
    print(user_profiles)
    if(user_profiles):
        save_user_profile_serializer = UserProfileSerializer(user_profiles)
        user_profile_dict = json.loads(json.dumps(save_user_profile_serializer.data))
        if(data.get('user_security_question_answer') == user_profile_dict['user_security_question_answer']):
            user_profile_dict["user_password"] = data.get('user_password')
            save_user_profile_serializer.update(user_profile_dict)
            return JsonResponse(user_profile_dict,status=200)
        else:
            response_msg.update({"msg" : "Security Question Answer is not Correct"})
            return JsonResponse(response_msg,status=201)
    else:
        response_msg.update({"msg" : "User record not Found"})
        return JsonResponse(response_msg,status=201)


@api_view(['GET'])
@permission_classes([])
def get_artist_relation(request):
    data = request.data
    if(data):
        artist_relations = ArtistRelation.objects.filter(artist_profile_id_1 = data.get('artist_profile_id_1'),artist_profile_id_2 = data.get('artist_profile_id_2'),
                          artist_relation = data.get('artist_relation'))
        if(artist_relations):
            artist_relation_data = ArtistRelationSerializer(artist_relations,many=True)
            return Response(artist_relation_data.data)
        else:
            return None
    return Response("ERROR")

@api_view(['PUT'])
@permission_classes([])
def add_new_artist_relation(request):
    data = request.data
    artist_relation_string = data.get('artist_relation')
    artist_firstname_1 = data.get('artist_firstname_1')
    artist_lastname_1 = data.get('artist_lastname_1')
    artist_email_id_1 = data.get('artist_email_id_1')
    artist_email_id_2 = data.get('artist_email_id_2')
    if(artist_email_id_2):
        print("proceeding to add existing artist")
        #get the artist profile of artist being added to the lineage
        #Once we have the artist details we will add them to the 
        artist_profile_one = ArtistProfile.objects.filter(artist_last_name = artist_lastname_1,
                            artist_email_address = artist_email_id_1,artist_first_name = artist_firstname_1)
        artist_profile_two =  ArtistProfile.objects.filter(artist_last_name = data.get('artist_lastname_2'),
                            artist_email_address = artist_email_id_2,artist_first_name = data.get('artist_firstname_2'))
        #Convert the above two object sets into JSON/Dict
        artist_profile_one_serializer = ArtistProfileSrializer(artist_profile_one,many=True)
        artist_profile_two_serializer = ArtistProfileSrializer(artist_profile_two,many=True)
        artist_profile_one_data = json.loads(json.dumps(artist_profile_one_serializer.data))
        artist_profile_two_data = json.loads(json.dumps(artist_profile_two_serializer.data))
        print("Printing artist 1")
        print(artist_profile_one_data)
        if(len(artist_profile_two_data) == 0):
            return JsonResponse({"msg" : "Error adding artist to lineage"},safe=False,status=201)
        print(artist_profile_two_data)
        artist_name_1 = artist_profile_one_data[0].get('artist_first_name') + ' ' + artist_profile_one_data[0].get('artist_last_name')
        print(artist_name_1)
        artist_name_2 = artist_profile_two_data[0].get('artist_first_name') + ' ' + artist_profile_two_data[0].get('artist_last_name')
        print(artist_name_2)
        artist_relation_dict = {'artist_profile_id_1' : artist_profile_one_data[0].get('artist_profile_id'), 'artist_profile_id_2' : artist_profile_two_data[0].get('artist_profile_id'),
                                'artist_name_1' : artist_name_1,
                                'artist_email_id_1' : artist_profile_one_data[0].get('artist_email_address'), 'artist_name_2' : artist_name_2,
                                'artist_email_id_2' : artist_profile_two_data[0].get('artist_email_address'), 'artist_relation' : artist_relation_string    }
        #save_artist_relation_serializer = ArtistRelationSerializer(artist_relation_dict,many=True)
        #if(save_artist_relation_serializer.is_valid()):
        #save_artist_relation_serializer.create(json.dumps(artist_relation_dict))
        #if(save_artist_relation_serializer.is_valid()):
        #save_artist_relation_serializer.create(json.dumps(artist_relation_dict))
        #return JsonResponse(save_artist_relation_serializer.data, status = 201)
        artist_check_relation = ArtistRelation.objects.filter(artist_profile_id_1 = artist_profile_one_data[0].get('artist_profile_id'), artist_profile_id_2 = artist_profile_two_data[0].get('artist_profile_id'),
                                artist_relation = artist_relation_string).first()
        if(artist_check_relation):
            return JsonResponse({"msg" : "Lineage already exists"},safe=False,status=201)
        artist_relation_object = ArtistRelation.objects.create(
            artist_profile_id_1 = artist_profile_one_data[0].get('artist_profile_id'),
            artist_profile_id_2 = artist_profile_two_data[0].get('artist_profile_id'),
            artist_name_1 = artist_name_1,
            artist_email_id_1 = artist_profile_one_data[0].get('artist_email_address'),
            artist_name_2 = artist_name_2,
            artist_email_id_2 = artist_profile_two_data[0].get('artist_email_address'),
            artist_website_2 = "",
            artist_relation = artist_relation_string,
            start_date = None,
            end_date = None,
            duration_years = None,
            duration_months = None,
            relation_identifier = None,
            works = None,
            relation_genres = None,
            relation_user_genres = None
        )
        artist_relation_object.save()
        return JsonResponse({"msg" : "Artist added to Lineage Successfully"},safe=False,status = 200)
    #Here we assume that new artist is being added
    #First we create a new aritist account for the Artist being added to the lineage
    #to maintain authenticity we create hash of email
    print("Adding a new artist")
    letters = string.ascii_lowercase
    strTohash = ''.join(random.choice(letters) for i in range(10))
    print(strTohash)
    result = hashlib.md5(strTohash.encode())
    artist_email_id_2 = 'dummyemail@' + result.hexdigest()
    print(artist_email_id_2)
    artist_profile_2 = {'artist_first_name' : data.get('artist_firstname_2'), 'artist_last_name' : data.get('artist_lastname_2'),
                        'artist_email_address' : artist_email_id_2, 'artist_gender' : '', 'profile_name' : artist_email_id_2, 'artist_photo_path' : None}
    save_artist_profile_serializer = ArtistProfileSrializer(data=artist_profile_2)
    #if(save_artist_profile_serializer.is_valid()):
    save_artist_profile_serializer.create(artist_profile_2)
    #Now its time to save the relation in the Database
    artist_profile_one = ArtistProfile.objects.filter(artist_last_name = data.get('artist_lastname_1'),
                            artist_email_address = data.get('artist_email_id_1'),artist_first_name = data.get('artist_firstname_1'))
    print("Profile 1 DB bject")
    print(artist_profile_one)
    print("Requested body object")
    print(data)
    artist_profile_two = ArtistProfile.objects.filter(artist_last_name = data.get('artist_lastname_2'),
                          artist_email_address = artist_email_id_2,artist_first_name = data.get('artist_firstname_2'))
    #Convert the above two object sets into JSON/Dict
    artist_profile_one_serializer = ArtistProfileSrializer(artist_profile_one,many=True)
    artist_profile_two_serializer = ArtistProfileSrializer(artist_profile_two,many=True)
    artist_profile_one_data = json.loads(json.dumps(artist_profile_one_serializer.data))
    artist_profile_two_data = json.loads(json.dumps(artist_profile_two_serializer.data))
    print("Here is the ")
    print(artist_profile_one_data)
    print(artist_profile_two_data)
    artist_name_1 = artist_profile_one_data[0].get('artist_first_name') + ' ' + artist_profile_one_data[0].get('artist_last_name')
    print(artist_name_1)
    artist_name_2 = artist_profile_two_data[0].get('artist_first_name') + ' ' + artist_profile_two_data[0].get('artist_last_name')
    print(artist_name_2)
    artist_relation_dict = {'artist_profile_id_1' : artist_profile_one_data[0].get('artist_profile_id'), 'artist_profile_id_2' : artist_profile_two_data[0].get('artist_profile_id'),
                             'artist_name_1' : artist_name_1,
                             'artist_email_id_1' : artist_profile_one_data[0].get('artist_email_address'), 'artist_name_2' : artist_name_2,
                             'artist_email_id_2' : artist_profile_two_data[0].get('artist_email_address'), 'artist_relation' : artist_relation_string}
    #save_artist_relation_serializer = ArtistRelationSerializer(artist_relation_dict,many=True)
    #if(save_artist_relation_serializer.is_valid()):
    #save_artist_relation_serializer.create(json.dumps(artist_relation_dict))
    #return JsonResponse(save_artist_relation_serializer.data, status = 201)
    # artist_relation_object = ArtistRelation.objects.create(
    #     artist_profile_id_1 = artist_profile_one_data[0].get('artist_profile_id'),
    #     artist_profile_id_2 = artist_profile_two_data[0].get('artist_profile_id'),
    #     artist_name_1 = artist_name_1,
    #     artist_email_id_1 = artist_profile_one_data[0].get('artist_email_address'),
    #     artist_name_2 = artist_name_2,
    #     artist_email_id_2 = artist_profile_two_data[0].get('artist_email_address'),
    #     artist_website_2 = "",
    #     artist_relation = artist_relation,
    #     start_date = None,
    #     end_date = None,
    #     duration_years = None,
    #     duration_months = None,
    #     relation_identifier = None,
    #     works = None,
    #     relation_genres = None,
    #     relation_user_genres = None
    # )
    print("Adding the relation")
    print(artist_relation_dict)
    print(type(artist_relation_dict))
    artist_relation_serializer = ArtistRelationSerializer(artist_relation_dict)
    #Checking for the existing artist relation
    artist_relation_exists = ArtistRelation.objects.filter(artist_profile_id_1 = artist_profile_one_data[0].get('artist_profile_id'),
                             artist_profile_id_2 = artist_profile_two_data[0].get('artist_profile_id'),artist_relation = artist_relation_string)
    print(artist_relation_exists)
    if(len(artist_relation_exists)==0):
        print("Creating a new Artist Relation")
        artist_relation_serializer.create(artist_relation_dict)
        response_msg = {}
        response_msg.update({"msg" : "Lineage added Successfully!"})
        return JsonResponse(response_msg,safe=False,status = 200)
    else:
        print("Updating the artist relation")
        artist_relation_serializer.update(artist_relation_dict)
        response_msg = {}
        response_msg.update({"msg" : "Lineage Updated Successfully!"})
        return JsonResponse(response_msg,safe=False,status = 200)

@api_view(['PUT'])
@permission_classes([])
def add_existing_artist_relation(request):
    data = request.data
    artist_relation = data.get('artist_relation')
    artist_firstname_1 = data.get('artist_firstname_1')
    artist_lastname_1 = data.get('artist_lastname_1')
    artist_email_id_1 = data.get('artist_email_id_1')
    artist_email_id_2 = data.get('artist_email_id_2')
    #get the artist profile of artist being added to the lineage
    #Once we have the artist details we will add them to the 
    artist_profile_one = ArtistProfile.objects.filter(artist_last_name = artist_lastname_1,
                          artist_email_address = artist_email_id_1,artist_first_name = artist_firstname_1)
    artist_profile_two =  ArtistProfile.objects.filter(artist_last_name = data.get('artist_lastname_2'),
                          artist_email_address = artist_email_id_2,artist_first_name = data.get('artist_firstname_2'))
    #Convert the above two object sets into JSON/Dict
    artist_profile_one_serializer = ArtistProfileSrializer(artist_profile_one,many=True)
    artist_profile_two_serializer = ArtistProfileSrializer(artist_profile_two,many=True)
    artist_profile_one_data = json.loads(json.dumps(artist_profile_one_serializer.data))
    artist_profile_two_data = json.loads(json.dumps(artist_profile_two_serializer.data))
    print(artist_profile_two_data)
    artist_name_1 = artist_profile_one_data[0].get('artist_first_name') + ' ' + artist_profile_one_data[0].get('artist_last_name')
    print(artist_name_1)
    artist_name_2 = artist_profile_two_data[0].get('artist_first_name') + ' ' + artist_profile_two_data[0].get('artist_last_name')
    print(artist_name_2)
    artist_relation_dict = {'artist_profile_id_1' : artist_profile_one_data[0].get('artist_profile_id'), 'artist_profile_id_2' : artist_profile_two_data[0].get('artist_profile_id'),
                            'artist_name_1' : artist_name_1,
                             'artist_email_id_1' : artist_profile_one_data[0].get('artist_email_address'), 'artist_name_2' : artist_name_2,
                             'artist_email_id_2' : artist_profile_two_data[0].get('artist_email_address'), artist_relation : artist_relation}
    #save_artist_relation_serializer = ArtistRelationSerializer(artist_relation_dict,many=True)
    #if(save_artist_relation_serializer.is_valid()):
    #save_artist_relation_serializer.create(json.dumps(artist_relation_dict))
    #return JsonResponse(save_artist_relation_serializer.data, status = 201)
    artist_relation_object = ArtistRelation.objects.create(
        artist_profile_id_1 = artist_profile_one_data[0].get('artist_profile_id'),
        artist_profile_id_2 = artist_profile_two_data[0].get('artist_profile_id'),
        artist_name_1 = artist_name_1,
        artist_email_id_1 = artist_profile_one_data[0].get('artist_email_address'),
        artist_name_2 = artist_name_2,
        artist_email_id_2 = artist_profile_two_data[0].get('artist_email_address'),
        artist_website_2 = "",
        artist_relation = artist_relation,
        start_date = None,
        end_date = None,
        duration_years = None,
        duration_months = None,
        relation_identifier = None,
        works = None,
        relation_genres = None,
        relation_user_genres = None
    )
    artist_relation_object.save()
    return JsonResponse(artist_relation_object,safe=False,status = 200)

@api_view(['GET'])
@permission_classes([])
def home_view(request):
    return Response('Welcome to Dancestry')


@api_view(['PUT'])
@permission_classes([])
def is_existing_artist(request):
    data = request.data
    response_msg ={}
    if(data):
        artist_profiles = ArtistProfile.objects.filter(artist_last_name = data.get('artist_last_name')
                          ,artist_first_name = data.get('artist_first_name'))
        if(artist_profiles):
            artist_profile_data = ArtistProfileSrializer(artist_profiles,many=True)
            artist_profile_dict = json.loads(json.dumps(artist_profile_data.data))
            response_msg.update({"msg": "Artist record found"})
            return JsonResponse(artist_profile_dict,safe=False,status=200)
        else:
            artist_profile_data = ArtistProfileSrializer(artist_profiles,many=True)
            artist_profile_dict = json.loads(json.dumps(artist_profile_data.data))
            response_msg.update({"msg": "Artist record not found, Please enter your details"})
            return JsonResponse(artist_profile_dict,status=200,safe=False)
    response_msg.update({"msg": "an error occured"})
    return JsonResponse(response_msg,status=400)

@api_view(['PUT'])
@permission_classes([])
def get_user_security_question(request):
    data =request.data
    response_msg = {}
    if(data):
        user_profiles = UserProfile.objects.filter(user_email_address = data.get('user_email_address')).first()
        if(user_profiles):
            user_profile_data = UserProfileSerializer(user_profiles)
            response_msg.update({"msg" : "Question fetched Successfully"})
            print(user_profile_data.data)
            return Response(user_profile_data.data,status=200)
        else:
            response_msg.update({"msg" : "User not found"})
            return JsonResponse(response_msg,status=201)
        response_msg.update({"msg" : "Unknown errot"})
    return JsonResponse(user_profile_data,status=201)


 #retrive artist profiles based on the last name
@api_view(['POST'])
@permission_classes([])
def get_artist_profile_by_lastname(request):
    data = request.data
    response_data = {}
    if(data):
        artist_profiles = ArtistProfile.objects.filter(artist_last_name__contains = data.get('artist_last_name'))
        print(artist_profiles)
        if(artist_profiles):
            artist_profile_data = ArtistProfileSrializer(artist_profiles,many=True)
            return JsonResponse(artist_profile_data.data,status=200,safe=False)
        else:
            response_data.update({"msg" : "No matched users Found"})
            return JsonResponse(response_data,status=201)
    response_data.update({"msg" : "Unknown error"})
    return JsonResponse(response_data,status=201)

@api_view(['GET'])
@permission_classes([])
def get_full_network(request):
    artist_relations = ArtistRelation.objects.all()
    edges = []
    #Fetching all the artists
    all_artists = ArtistProfile.objects.all()
    artist_data = []
    if(all_artists):
        artist_serializer = ArtistProfileSrializer(all_artists,many=True)
        artist_serialized_data = json.loads(json.dumps(artist_serializer.data))
        counter = 0
        for artist in artist_serialized_data:
            artist_object = {}
            artist_object.update({"id" : artist.get('artist_profile_id'), "label" : artist.get('artist_first_name') + ' ' + artist.get('artist_last_name'), "group" : 0})
            artist_data.append(artist_object)

    print("Printing artists")
    print(artist_data)
    #looping through artist_relations
    if(artist_relations):
        artist_relation_serializer = ArtistRelationSerializer(artist_relations,many=True)
        artist_relation_one_data = json.loads(json.dumps(artist_relation_serializer.data))
        #print(artist_relation_one_data)

        print("type of artist relation serializer")
        print(type(artist_relation_one_data))
        for relation in artist_relation_one_data:
            counter = 0
            relation_object = {}
            #print(relation.get('artist_profile_id_1'))
            edges.append({"from" : relation.get('artist_profile_id_1'), "to" : relation.get('artist_profile_id_2')})

    relation_network = {}
    relation_network.update({"edges" : edges})
    relation_network.update({"nodes": artist_data})
    return JsonResponse(relation_network,status=200,safe=False)


@api_view(['PUT'])
@permission_classes([])
def get_artist_relation_by_Name(request):
    data = request.data
    if(data):
        artist_relations = ArtistRelation.objects.filter(artist_name_1 = data.get('artist_firstname_1') + ' ' + data.get('artist_lastname_1'))
        if(artist_relations):
            artist_relation_data = ArtistRelationSerializer(artist_relations,many=True)
            artist_relation_dict = json.loads(json.dumps(artist_relation_data.data))
            return JsonResponse(artist_relation_dict,status=200,safe=False)
        else:
            artist_relation_data = ArtistRelationSerializer(artist_relations,many=True)
            artist_relation_dict = json.loads(json.dumps(artist_relation_data.data))
            return JsonResponse(artist_relation_dict,status=200,safe=False)
    return Response("ERROR")


#retrive artist profiles based on the last name
@api_view(['PUT'])
@permission_classes([])
def get_artist_profile_relations(request):
    data = request.data

    Studied_under = []
    Danced_with = []
    if(data):
        artist_profiles = ArtistProfile.objects.filter(artist_last_name = data.get('artist_last_name'),
                          artist_email_address = data.get('artist_email_address'),artist_first_name = data.get('artist_first_name'))
        if(artist_profiles):
            artist_profile_data = ArtistProfileSrializer(artist_profiles,many=True)
            artist_profile_dict = json.loads(json.dumps(artist_profile_data.data))
            # print(artist_profile_dict[0].get('artist_profile_id'))
            artist_profile_relation = ArtistRelation.objects.filter(artist_profile_id_1 = artist_profile_dict[0].get('artist_profile_id'))
            # print(artist_profile_relation)
            artist_profile_relation_data = ArtistRelationSerializer(artist_profile_relation,many=True)
            artist_relation_dict = json.loads(json.dumps(artist_profile_relation_data.data))
            # print(artist_relation_dict)
            for relation in artist_relation_dict:
                print("relation")
                print(relation)
                if(relation.get('artist_relation') == 'Studied Under'):
                    Studied_under.append({"name" :relation.get('artist_name_2')})
                if(relation.get('artist_relation') == 'Danced With'):
                    Danced_with.append({"name" : relation.get('artist_name_2')})
            response = []
            response.append(Studied_under)
            response.append(Danced_with)
            print("printing lists")
            print(response)
            return JsonResponse(response,safe=False,status=200)
        else:
            return JsonResponse({"msg" : "Unkown Error"},safe=False,status=201)
    return Response("ERROR")


#retrive artist profile relation by ID
@api_view(['PUT'])
@permission_classes([])
def get_artist_profile_relation_by_Id(request):
    data = request.data
    print("printing the request param")
    print(data)
    artist_profile_relation = ArtistRelation.objects.filter(artist_profile_id_1 = data.get('artist_profile_id'))
    artist_profile_relation_data = ArtistRelationSerializer(artist_profile_relation,many=True)
    artist_relation_dict = json.loads(json.dumps(artist_profile_relation_data.data))
    print("printing the response data")
    print(artist_relation_dict)
    return JsonResponse(artist_relation_dict,safe=False,status=200)